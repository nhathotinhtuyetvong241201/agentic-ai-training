#!/usr/bin/env bash
# Chạy mini-swe-agent hàng loạt trên SWE-bench, lưu trajectory vào $OUT.
# Ví dụ:
#   SLICE=0:20 WORKERS=8 ./run_batch.sh
#   SUBSET=rebench SPLIT=filtered FILTER='^0b01001001__spectree-64$' WORKERS=1 OUT=runs/spectree64 ./run_batch.sh
set -euo pipefail
cd "$(dirname "$0")"

SUBSET="${SUBSET:-verified}"      # lite | verified | full | smith | đường dẫn dataset riêng
SPLIT="${SPLIT:-test}"
SLICE="${SLICE:-0:5}"
FILTER="${FILTER:-}"
WORKERS="${WORKERS:-3}"
OUT="${OUT:-runs/$(date +%Y%m%d_%H%M%S)}"
EXTRA_CONFIG="${EXTRA_CONFIG:-}"  # vd: "-c agent.step_limit=50"

args=(--subset "$SUBSET" --split "$SPLIT" -w "$WORKERS" -o "$OUT"
      -c swebench.yaml -c vllm_model.yaml)
[[ -n "$SLICE" && -z "$FILTER" ]] && args+=(--slice "$SLICE")
[[ -n "$FILTER" ]] && args+=(--filter "$FILTER")
# shellcheck disable=SC2206
[[ -n "$EXTRA_CONFIG" ]] && args+=($EXTRA_CONFIG)

export MSWEA_COST_TRACKING=ignore_errors
mini-extra swebench "${args[@]}"

python collect_trajs.py "$OUT"
