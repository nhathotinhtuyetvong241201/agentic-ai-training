# Chạy thử 1 task trên NVIDIA Run:ai (không có Docker)

Task: `0b01001001__spectree-64` (SWE-rebench, split `filtered`; đã xuất sẵn ra `data/spectree64/test.jsonl`),
image `docker.io/swerebench/sweb.eval.x86_64.0b01001001_1776_spectree-64:latest`.

## Ý tưởng

Bình thường mini-swe-agent tự gọi `docker run` / `docker exec`. Run:ai không cho cài Docker, nhưng cho tạo workload từ
một image bất kỳ. Vì vậy ta **để Run:ai chạy container từ image của task**, rồi chạy mini-swe-agent **ngay bên trong
container đó**: lệnh của agent chạy trực tiếp trong container (`runai/bash_local_env.py`), không cần Docker.

```
Jupyter workload (đã có)                 Training workload mới (chỉ CPU)
  chuẩn bị PVC 1 lần                       image = swerebench/...spectree-64
        │                                   command = bash <ROOT>/swe-traj/runai/run_task.sh
        ▼                                         │  agent sửa code trong /testbed
PVC  <ROOT>/swe-traj   script, config, data/  ◄─────────┤  (mount cùng PVC, CÙNG đường dẫn)
     <ROOT>/mswea-venv Python + mini-swe-agent    │
     <ROOT>/hf         cache của datasets         │
     <ROOT>/runs       trajectory  ◄──────────────┘  ghi kết quả
                                                   └──► vLLM endpoint (gọi qua mạng)
```

`<ROOT>` là đường dẫn mount PVC (dưới đây ví dụ `/data`, thay bằng đường dẫn của bạn).

## Điều kiện cần

| Cần | Vì sao |
|---|---|
| Một PVC (data source) gắn được vào **cả** Jupyter workload **và** workload mới, ở **cùng đường dẫn** | venv trên PVC chứa đường dẫn tuyệt đối |
| Workload mới chạy bằng **root** (user mặc định của image) | Agent phải sửa file trong `/testbed` (thuộc root) |
| Pod gọi được vLLM endpoint | `api_base` trong `vllm_model.yaml` |
| Cluster pull được image từ `docker.io` (hoặc có registry mirror) | Image của task |
| Jupyter cài được gói từ PyPI (trực tiếp hoặc qua mirror nội bộ) | Cài mini-swe-agent. **Không** cần Hugging Face: task đã nằm trong `data/` |

## Bước 1. Chép code lên PVC (terminal Jupyter)

Upload `swe-traj.zip` lên Jupyter, rồi giải nén vào thư mục gốc của PVC:

```bash
cd /data && unzip -o ~/swe-traj.zip
```

## Bước 2. Trỏ tới vLLM

Lấy tên model (trường `id`):

```bash
curl -s http://<vllm-host>:<port>/v1/models
```

Sửa `/data/swe-traj/vllm_model.yaml`:

```yaml
model:
  model_name: "hosted_vllm/<id>"
  model_kwargs:
    api_base: "http://<vllm-host>:<port>/v1"   # địa chỉ pod khác truy cập được, KHÔNG dùng localhost
```

## Bước 3. Chuẩn bị PVC

```bash
bash /data/swe-traj/runai/setup_pvc.sh
```

Script cài Python 3.12 + mini-swe-agent vào `/data/mswea-venv` (Python cũng nằm trên PVC nên dùng được trong mọi image),
rồi thử đọc task từ `/data/swe-traj/data/spectree64` ở chế độ offline. Dòng cuối phải in `1 task: ['0b01001001__spectree-64']`.

Workload task **không cần internet**: dataset đọc từ file, litellm dùng bảng giá có sẵn (`LITELLM_LOCAL_MODEL_COST_MAP`),
chỉ cần gọi được vLLM.

## Bước 4. Tạo workload cho task

Trên giao diện Run:ai: **Workloads → New workload → Training**, chọn project, rồi:

| Mục | Giá trị |
|---|---|
| Image | `docker.io/swerebench/sweb.eval.x86_64.0b01001001_1776_spectree-64:latest` |
| Command | `bash` |
| Arguments | `/data/swe-traj/runai/run_task.sh 0b01001001__spectree-64` |
| Compute | Chỉ CPU: 2 CPU, 6GB RAM, **0 GPU** |
| Data source | PVC ở Bước 1, mount tại `/data` |
| User | Giữ user của image (root), không bật "run as non-root" |

Hoặc bằng Run:ai CLI, nếu notebook có sẵn. Đây là cờ của CLI v2; kiểm tra bằng `runai training submit --help`:

```bash
runai training submit spectree-64 -p <project> -i docker.io/swerebench/sweb.eval.x86_64.0b01001001_1776_spectree-64:latest --cpu-core-request 2 --cpu-memory-request 6G --existing-pvc claimname=<pvc>,path=/data --command -- bash /data/swe-traj/runai/run_task.sh 0b01001001__spectree-64
```

## Bước 5. Theo dõi và lấy kết quả

Dòng đầu tiên của log phải là `user=root uid=0  ROOT=/data ...`. Workload xong khi log in `Wrote 1 trajectories`.

Kết quả nằm ở `/data/runs/runai/0b01001001__spectree-64/`:

```
preds.json                                        patch agent nộp
trajectories.jsonl                                trajectory gọn (như Cách A)
0b01001001__spectree-64/0b01001001__spectree-64.traj.json   trajectory đầy đủ
minisweagent.log
```

Xem trong terminal Jupyter:

```bash
/data/mswea-venv/bin/mini-extra inspector /data/runs/runai/0b01001001__spectree-64
```

## Chạy task khác

Ở máy có internet (vd Mac, trong `swe-traj/.venv` hoặc `~/venvs/mswea`), xuất task ra file:

```bash
python export_tasks.py --subset rebench --split filtered --filter '^0b01001001__spectree-64$' -o data/spectree64
```

```bash
python export_tasks.py --subset verified --split test --slice 0:10 -o data/verified_0_10
```

Lệnh in ra `instance_id` và image của từng task. Chép thư mục `data/...` lên `/data/swe-traj/data/`, rồi tạo workload với
image tương ứng, thêm biến môi trường `SUBSET=/data/swe-traj/data/verified_0_10` và arguments
`/data/swe-traj/runai/run_task.sh <instance_id>`.

## Các file trong `runai/`

| File | Vai trò |
|---|---|
| `bash_local_env.py` | Environment chạy lệnh của agent bằng `bash -c` ngay trong container (bản `local` gốc dùng `/bin/sh`) |
| `local_env.yaml` | Overlay config: dùng environment trên thay cho `docker` |
| `testbed_bashrc.sh` | `BASH_ENV` của mọi lệnh: kích hoạt conda env `testbed`. Cần vì `/root/.bashrc` của image SWE-rebench chỉ `conda activate base` |
| `setup_pvc.sh` | Bước 3 |
| `run_task.sh` | Command của workload. Biến tuỳ chọn: `SUBSET`, `SPLIT`, `RUN_NAME`, `EXTRA_CONFIG` |

## Lỗi hay gặp

| Triệu chứng | Cách xử lý |
|---|---|
| `Không ghi được /testbed` | Workload đang chạy non-root. Bỏ tuỳ chọn ép non-root / đặt UID 0, hoặc hỏi admin cluster |
| `mswea-venv/bin/mini-extra: No such file` | PVC mount ở đường dẫn khác với Jupyter. Mount cùng một đường dẫn |
| `ImagePullBackOff` | Cluster không ra được `docker.io`. Đẩy image sang registry nội bộ rồi dùng tên đó (agent không phụ thuộc tên image) |
| `Connection refused` / `APIConnectionError` | `api_base` sai hoặc đang là `localhost` |
| `uv venv` / `uv pip install` lỗi mạng | Jupyter không ra được PyPI/GitHub. Cần gói cài offline (wheel + Python) chuẩn bị từ máy có internet |
| `Instance filter: 1 -> 0` / `Running on 0 instances` | Task không có trong file `data/.../test.jsonl`. Xuất lại bằng `export_tasks.py` |

> **Lưu ý an toàn:** agent chạy bằng root trong container có mount PVC, nên về lý thuyết một lệnh sai có thể xoá file
> trên PVC. Nên dùng PVC riêng cho việc này.
>
> **Chấm điểm (resolved hay không):** harness SWE-bench cần Docker nên không chạy được ở đây. Muốn chấm phải chạy test
> của task ngay trong pod sau khi agent xong.
