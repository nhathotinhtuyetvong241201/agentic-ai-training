#!/usr/bin/env python3
"""Xuất một số task từ dataset trên Hugging Face ra file JSONL, để chạy ở máy KHÔNG có internet.

Chạy ở máy có internet (vd Mac), rồi chép thư mục output sang máy kia và dùng `--subset <thư mục> --split test`:
    python export_tasks.py --subset rebench --split filtered --filter '^0b01001001__spectree-64$' -o data/spectree64
    python export_tasks.py --subset verified --split test --slice 0:10 -o data/verified_0_10
"""

import argparse
import json
from pathlib import Path

from datasets import load_dataset

from minisweagent.run.benchmarks.swebench import DATASET_MAPPING, filter_instances, get_swebench_docker_image_name

p = argparse.ArgumentParser()
p.add_argument("--subset", default="rebench")
p.add_argument("--split", default="filtered")
p.add_argument("--slice", default="")
p.add_argument("--filter", default="")
p.add_argument("-o", "--output", type=Path, required=True, help="thư mục output, sẽ chứa test.jsonl")
a = p.parse_args()

instances = filter_instances(
    list(load_dataset(DATASET_MAPPING.get(a.subset, a.subset), split=a.split)), filter_spec=a.filter, slice_spec=a.slice
)
a.output.mkdir(parents=True, exist_ok=True)
(a.output / "test.jsonl").write_text("".join(json.dumps(x, ensure_ascii=False, default=str) + "\n" for x in instances))
for x in instances:
    print(x["instance_id"], get_swebench_docker_image_name(x))
print(f"{len(instances)} task -> {a.output / 'test.jsonl'}  (dùng: --subset {a.output} --split test)")
