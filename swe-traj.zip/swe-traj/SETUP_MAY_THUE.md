# Setup máy thuê RTX 5060 Ti (Windows 10) để chạy mini-swe-agent + vLLM

Máy: 1× RTX 5060 Ti 16GB · i5-14600KF · RAM 28GB · SSD 1600GB · Windows 10.

## Cách tổ chức

vLLM không chạy trực tiếp trên Windows, nên toàn bộ sẽ chạy trong **WSL2 (Ubuntu)** trên chính máy này:

```
Windows 10 (driver NVIDIA)
└── WSL2 Ubuntu 24.04
    ├── vLLM  ──── serve Qwen3-8B-AWQ trên GPU, cổng 8000
    ├── Docker ─── mỗi task SWE-bench là một container
    └── mini-swe-agent ── gọi vLLM qua localhost:8000, chạy lệnh trong container, ghi trajectory
```

Máy này là x86_64 nên chạy được image SWE-bench (khác với Mac).

## Chọn model cho 16GB VRAM

| Model | Kích thước weights | Ghi chú |
|---|---|---|
| **`Qwen/Qwen3-8B-AWQ`** (mặc định) | ~6.1GB | Còn ~7GB cho KV cache → context 32k, vài request song song. Tool calling ổn với parser `hermes` |
| `Qwen/Qwen3-14B-AWQ` | ~10GB | Thông minh hơn nhưng KV cache chật: chỉ nên dùng `MAX_LEN=24576 MAX_SEQS=2` |
| `Qwen/Qwen3-Coder-30B-A3B-Instruct` | ~60GB bf16 / ~17GB 4-bit | **Không vừa** 16GB |

Mặc định trong `vllm_serve.sh` và `vllm_model.yaml` đã đặt sẵn cho Qwen3-8B-AWQ, tắt thinking để chạy nhanh hơn.

---

## Bước 0. Chuẩn bị trên Windows

Kết nối vào máy (Remote Desktop theo hướng dẫn của nhà cung cấp), mở **PowerShell (Run as Administrator)**.

Kiểm tra phiên bản Windows — cần build **19044 (21H2) trở lên** để WSL2 dùng được GPU:

```powershell
[System.Environment]::OSVersion.Version
```

Kiểm tra driver NVIDIA — RTX 50 series cần driver **≥ 570**:

```powershell
nvidia-smi
```

Nên tắt sleep để máy không ngủ khi bạn ngắt RDP:

```powershell
powercfg /change standby-timeout-ac 0
```

Xem ổ nào là ổ 1600GB và còn bao nhiêu chỗ trống:

```powershell
Get-PSDrive -PSProvider FileSystem
```

Image SWE-bench mỗi cái 2–5GB; chạy vài trăm task cần vài trăm GB. Nếu ổ `C:` còn ít hơn ~300GB thì làm thêm
**Bước 1b** để chuyển Ubuntu sang ổ lớn.

## Bước 1. Cài WSL2 + Ubuntu

```powershell
wsl --install -d Ubuntu-24.04
```

Khởi động lại máy nếu được yêu cầu. Sau đó mở **Ubuntu** từ Start menu, tạo username/password cho Linux.

> **Nếu báo lỗi kiểu "virtualization is not enabled" / `0x80370102`:** máy thuê là máy ảo chưa bật nested virtualization,
> nên WSL2 không chạy được. Hãy hỏi nhà cung cấp bật nó, hoặc đổi OS của máy sang Ubuntu (xem nút ⓘ cạnh "Windows 10" trên
> trang thuê). Với Ubuntu chạy thẳng thì bỏ qua Bước 0–2, chỉ cần chạy `setup_wsl.sh` (bỏ qua bước kiểm tra systemd).

### Bước 1b (chỉ khi ổ C: thiếu chỗ). Chuyển Ubuntu sang ổ lớn

Ví dụ ổ lớn là `D:`. Trong PowerShell:

```powershell
wsl --shutdown
```

```powershell
wsl --export Ubuntu-24.04 D:\ubuntu.tar
```

```powershell
wsl --unregister Ubuntu-24.04
```

```powershell
wsl --import Ubuntu-24.04 D:\WSL\Ubuntu D:\ubuntu.tar
```

Sau khi import, Ubuntu mặc định đăng nhập bằng root. Đặt lại user mặc định (thay `tenban` bằng username bạn tạo ở Bước 1):

```powershell
wsl -d Ubuntu-24.04 -u root -- bash -c "printf '[user]\ndefault=tenban\n' >> /etc/wsl.conf"
```

```powershell
wsl --shutdown
```

## Bước 2. Cấp RAM cho WSL

Mặc định WSL2 chỉ được dùng 50% RAM (~14GB), không đủ cho vLLM + nhiều container. Mở Notepad, tạo file
`C:\Users\<tên user Windows>\.wslconfig` với nội dung:

```ini
[wsl2]
memory=22GB
swap=16GB
```

Rồi áp dụng:

```powershell
wsl --shutdown
```

## Bước 3. Chép thư mục `swe-traj` lên máy

Trên Mac, nén thư mục (đã có sẵn file `swe-traj.zip` trong `/Users/binh.dv/vai/`). Chép file zip sang máy thuê bằng
copy–paste qua cửa sổ Remote Desktop (hoặc upload lên Google Drive rồi tải về), để ở Desktop của Windows.

Trong Ubuntu (thay `<WinUser>` bằng tên user Windows):

```bash
cp /mnt/c/Users/<WinUser>/Desktop/swe-traj.zip ~ && cd ~ && unzip -o swe-traj.zip && cd ~/swe-traj
```

## Bước 4. Cài môi trường (Docker, vLLM, mini-swe-agent, model)

```bash
bash ~/swe-traj/setup_wsl.sh
```

- Lần chạy đầu, nếu script báo đã bật systemd: chạy `wsl --shutdown` trong PowerShell, mở lại Ubuntu, chạy lại script.
- Script mất khoảng 10–20 phút (tải vLLM + PyTorch ~ vài GB và model ~6GB).
- Dòng cuối phải in ra `gpu NVIDIA GeForce RTX 5060 Ti ... sm (12, 0)`.

Đóng Ubuntu, mở lại (để quyền Docker có hiệu lực), rồi kiểm tra:

```bash
docker run --rm hello-world
```

## Bước 5. Chạy vLLM (cửa sổ 1)

Dùng `tmux` để tiến trình vẫn chạy khi bạn ngắt Remote Desktop:

```bash
tmux new -s vllm
```

```bash
source ~/venvs/vllm/bin/activate && cd ~/swe-traj && ./vllm_serve.sh
```

Chờ đến khi thấy `Application startup complete`. Tách khỏi tmux bằng `Ctrl+b` rồi `d` (vào lại: `tmux attach -t vllm`).

Kiểm tra server và tool calling:

```bash
curl -s localhost:8000/v1/models
```

```bash
curl -s localhost:8000/v1/chat/completions -H 'Content-Type: application/json' -d '{"model":"Qwen/Qwen3-8B-AWQ","messages":[{"role":"user","content":"List files in /tmp"}],"tools":[{"type":"function","function":{"name":"bash","parameters":{"type":"object","properties":{"command":{"type":"string"}},"required":["command"]}}}],"chat_template_kwargs":{"enable_thinking":false}}'
```

Kết quả đúng phải có `"tool_calls": [{"function": {"name": "bash", ...}}]`.

## Bước 6. Chạy thử 1 task (cửa sổ 2)

```bash
tmux new -s agent
```

```bash
source ~/venvs/mswea/bin/activate && cd ~/swe-traj
```

```bash
FILTER='^(django__django-11099)$' WORKERS=1 OUT=runs/smoke ./run_batch.sh
```

Lần đầu sẽ đứng ở "initializing" vài phút để `docker pull` image. Khi xong, kiểm tra:

```bash
python collect_trajs.py runs/smoke && mini-extra inspector runs/smoke
```

Ghi lại thời gian của task này để ước lượng thời gian chạy cả batch.

## Bước 7. Chạy nhiều task

```bash
SUBSET=verified SLICE=0:50 WORKERS=3 OUT=runs/verified_0_50 ./run_batch.sh
```

Chọn `WORKERS` cho máy này:

- **RAM** là giới hạn chính: WSL có 22GB; vLLM dùng ~4–6GB, mỗi container SWE-bench ~1–2GB. Bắt đầu với `3`, theo dõi bằng
  `free -h` và `docker stats`, rồi tăng lên `4–6` nếu còn dư.
- **GPU**: `vllm_serve.sh` cho tối đa 8 request đồng thời (`MAX_SEQS`), nên trên 8 workers không giúp gì thêm.

Ngắt giữa chừng cũng không sao: chạy lại cùng lệnh, task đã xong sẽ được bỏ qua.

Để tiết kiệm ổ cứng khi chạy nhiều task, thỉnh thoảng xoá image cũ:

```bash
docker image prune -a -f
```

## Bước 8. Lấy kết quả về

Trajectory nằm ở `~/swe-traj/runs/<tên run>/trajectories.jsonl` (và từng file `<instance_id>/<instance_id>.traj.json`).
Chép ra Windows để tải về Mac:

```bash
cp -r ~/swe-traj/runs /mnt/c/Users/<WinUser>/Desktop/
```

Muốn biết task nào resolved: xem Bước 7 trong [HUONG_DAN.md](HUONG_DAN.md) (`swebench` đã được cài trong `~/venvs/mswea`).

---

## Lỗi hay gặp trên máy này

| Triệu chứng | Cách xử lý |
|---|---|
| `nvidia-smi: command not found` trong Ubuntu | Cập nhật driver NVIDIA trên Windows, `wsl --shutdown`, mở lại. Không cài driver NVIDIA bên trong WSL |
| vLLM: `no kernel image is available` / `sm_120 is not compatible` | vLLM/PyTorch quá cũ cho RTX 50. Chạy `uv pip install -p ~/venvs/vllm/bin/python -U vllm --torch-backend=auto` |
| vLLM: `CUDA out of memory` / `No available memory for the cache blocks` lúc khởi động | Giảm `GPU_UTIL=0.80` hoặc `MAX_LEN=24576`; đóng app Windows đang dùng GPU (`nvidia-smi` trên Windows để xem) |
| Agent hay bị `finish_reason=length` / context đầy | Giảm `agent.step_limit` (vd `EXTRA_CONFIG="-c agent.step_limit=50"`) hoặc tăng `MAX_LEN` nếu VRAM cho phép |
| `permission denied ... docker.sock` | Chưa mở lại Ubuntu sau khi cài Docker |
| Container bị kill / máy chậm | Hết RAM: giảm `WORKERS`, hoặc tăng `memory` trong `.wslconfig` (tối đa ~25GB) |
| Mọi thứ dừng sau khi ngắt RDP | Chưa dùng `tmux`, hoặc Windows đi ngủ / tự update khởi động lại — tắt sleep (Bước 0) và tạm dừng Windows Update |
| Agent liên tục `Tool call error` | Model gọi tool sai định dạng. Kiểm tra lại lệnh `curl` ở Bước 5; đảm bảo `PARSER=hermes` cho Qwen3 |
