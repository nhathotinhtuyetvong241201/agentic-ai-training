#!/usr/bin/env python3
"""Gom toàn bộ *.traj.json (tìm đệ quy trong run_dir) thành 1 file JSONL.

Mỗi dòng: instance_id, exit_status, submission (patch), n_steps, messages (OpenAI chat format).
Mặc định bỏ `extra.response` (raw API response, rất nặng); dùng --keep-raw để giữ.

    python collect_trajs.py runs/20261118_100000
    python collect_trajs.py runs/20261118_100000 --only-submitted -o sft.jsonl
"""

import argparse
import json
from collections import Counter
from pathlib import Path


def clean_message(msg: dict, keep_raw: bool) -> dict:
    if keep_raw:
        return msg
    return {k: v for k, v in msg.items() if k not in ("extra", "provider_specific_fields") and v is not None}


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("run_dir", type=Path)
    p.add_argument("-o", "--output", type=Path, help="mặc định: <run_dir>/trajectories.jsonl")
    p.add_argument("--only-submitted", action="store_true", help="chỉ giữ task agent đã submit patch")
    p.add_argument("--keep-raw", action="store_true", help="giữ trường extra (raw response, timestamp...)")
    p.add_argument("--preds", type=Path, help="ghi thêm preds.json (định dạng SWE-bench) dựng lại từ các trajectory")
    a = p.parse_args()

    out = a.output or a.run_dir / "trajectories.jsonl"
    statuses: Counter = Counter()
    preds = {}
    n_written = 0
    with out.open("w") as f:
        for traj_path in sorted(a.run_dir.rglob("*.traj.json")):
            traj = json.loads(traj_path.read_text())
            info = traj.get("info", {})
            status = info.get("exit_status", "unknown")
            statuses[status] += 1
            iid = traj.get("instance_id") or traj_path.parent.name
            preds[iid] = {
                "model_name_or_path": info.get("config", {}).get("model", {}).get("model_name"),
                "instance_id": iid,
                "model_patch": info.get("submission") or "",
            }
            if a.only_submitted and status != "Submitted":
                continue
            messages = traj.get("messages", [])
            row = {
                "instance_id": iid,
                "exit_status": status,
                "submission": info.get("submission", ""),
                "n_steps": sum(m.get("role") == "assistant" for m in messages),
                "api_calls": info.get("model_stats", {}).get("api_calls"),
                "model": info.get("config", {}).get("model", {}).get("model_name"),
                "messages": [clean_message(m, a.keep_raw) for m in messages if a.keep_raw or m.get("role") != "exit"],
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            n_written += 1

    print(f"Wrote {n_written} trajectories -> {out}")
    if a.preds:
        a.preds.write_text(json.dumps(preds, indent=2))
        print(f"Wrote {len(preds)} predictions -> {a.preds}")
    print("exit_status:", dict(statuses))


if __name__ == "__main__":
    main()
