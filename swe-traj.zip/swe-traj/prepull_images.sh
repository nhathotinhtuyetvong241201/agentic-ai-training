#!/usr/bin/env bash
# Pull trước Docker image của các task, để batch không phải đợi pull giữa chừng.
# Tên image lấy bằng đúng hàm của mini-swe-agent (get_swebench_docker_image_name), chọn task bằng đúng
# filter_instances như `mini-extra swebench`, nên dùng cùng SUBSET/SPLIT/SLICE/FILTER với run_batch.sh.
#
#   source ~/venvs/mswea/bin/activate
#   ./prepull_images.sh                                  # 10 task đầu của SWE-rebench (split filtered)
#   SUBSET=verified SPLIT=test SLICE=0:50 ./prepull_images.sh
#   DRY_RUN=1 ./prepull_images.sh                        # chỉ in tên image, không pull
set -euo pipefail

SUBSET="${SUBSET:-rebench}"      # rebench | smith | verified | lite | ... | tên dataset HF | đường dẫn
SPLIT="${SPLIT:-filtered}"       # rebench: filtered / test; smith: train; verified: test
SLICE="${SLICE:-0:10}"
FILTER="${FILTER:-}"
PARALLEL="${PARALLEL:-3}"        # số image pull cùng lúc
DRY_RUN="${DRY_RUN:-0}"

list_file="$(mktemp)"
trap 'rm -f "$list_file"' EXIT

MSWEA_SILENT_STARTUP=1 python - "$SUBSET" "$SPLIT" "$SLICE" "$FILTER" "$list_file" <<'PY'
import sys
from pathlib import Path
from datasets import load_dataset
from minisweagent.run.benchmarks.swebench import DATASET_MAPPING, filter_instances, get_swebench_docker_image_name

subset, split, slice_spec, filter_spec, out = sys.argv[1:]
instances = filter_instances(
    list(load_dataset(DATASET_MAPPING.get(subset, subset), split=split)),
    filter_spec=filter_spec, slice_spec="" if filter_spec else slice_spec,
)
images = dict.fromkeys(get_swebench_docker_image_name(x) for x in instances)
print(f"{len(instances)} task -> {len(images)} image khác nhau", file=sys.stderr)
Path(out).write_text("".join(f"{i}\n" for i in images))
PY

cat "$list_file"
[[ "$DRY_RUN" == 1 ]] && exit 0

start=$SECONDS
failed=0
xargs -P "$PARALLEL" -n 1 sh -c 'docker pull -q "$1" >/dev/null && echo "OK   $1" || { echo "FAIL $1"; exit 1; }' _ < "$list_file" || failed=1
echo "Xong sau $((SECONDS - start))s."
docker images --format '{{.Repository}}:{{.Tag}}\t{{.Size}}' | grep -F -f <(sed 's/:latest$//; s/^docker\.io\///' "$list_file") || true
if [[ $failed == 1 ]]; then
  echo "Có image pull lỗi (xem dòng FAIL). Nếu là 'toomanyrequests': chạy 'docker login' rồi chạy lại script." >&2
  exit 1
fi
