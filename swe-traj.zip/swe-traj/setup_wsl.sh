#!/usr/bin/env bash
# Cài toàn bộ môi trường bên trong Ubuntu (WSL2) trên máy thuê:
#   Docker Engine, uv, venv vLLM (~/venvs/vllm), venv mini-swe-agent (~/venvs/mswea), tải sẵn model.
# Chạy lại nhiều lần được (bước nào xong rồi sẽ bỏ qua).
#   bash setup_wsl.sh
set -euo pipefail

MODEL="${MODEL:-Qwen/Qwen3-8B-AWQ}"
step() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }

step "1/7 Kiểm tra GPU (driver lấy từ Windows, KHÔNG cài driver NVIDIA trong WSL)"
if ! command -v nvidia-smi >/dev/null; then
  echo "Không thấy nvidia-smi. Cập nhật driver NVIDIA trên Windows (>= 570) rồi chạy 'wsl --shutdown' và thử lại." >&2
  exit 1
fi
nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv

step "2/7 Bật systemd cho WSL (cần cho Docker)"
if [[ "$(ps -p 1 -o comm=)" != "systemd" ]]; then
  grep -qs '^systemd=true' /etc/wsl.conf || printf '\n[boot]\nsystemd=true\n' | sudo tee -a /etc/wsl.conf >/dev/null
  echo "Đã bật systemd. Mở PowerShell trên Windows, chạy:  wsl --shutdown"
  echo "Sau đó mở lại Ubuntu và chạy lại script này."
  exit 0
fi

step "3/7 Gói hệ thống"
sudo apt-get update -y
sudo apt-get install -y git curl ca-certificates tmux unzip build-essential

step "4/7 Docker Engine (repo chính thức của Docker)"
if ! command -v docker >/dev/null; then
  sudo install -m 0755 -d /etc/apt/keyrings
  sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  sudo chmod a+r /etc/apt/keyrings/docker.asc
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
    | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
  sudo apt-get update -y
  sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin
fi
sudo systemctl enable --now docker
sudo usermod -aG docker "$USER"

step "5/7 uv"
if ! command -v uv >/dev/null && [[ ! -x "$HOME/.local/bin/uv" ]]; then
  curl -LsSf https://astral.sh/uv/install.sh | sh
fi
export PATH="$HOME/.local/bin:$PATH"

step "6/7 venv vLLM (~/venvs/vllm) và mini-swe-agent (~/venvs/mswea)"
mkdir -p ~/venvs
[[ -d ~/venvs/vllm ]] || uv venv -p 3.12 ~/venvs/vllm
uv pip install -p ~/venvs/vllm/bin/python vllm --torch-backend=auto
[[ -d ~/venvs/mswea ]] || uv venv -p 3.12 ~/venvs/mswea
uv pip install -p ~/venvs/mswea/bin/python mini-swe-agent swebench

step "7/7 Tải trước model $MODEL"
~/venvs/vllm/bin/python -c "from huggingface_hub import snapshot_download as d; print(d('$MODEL'))"

~/venvs/vllm/bin/python -c "import torch; print('torch', torch.__version__, 'cuda', torch.version.cuda, 'gpu', torch.cuda.get_device_name(0), 'sm', torch.cuda.get_device_capability(0))"

cat <<'EOF'

Xong. ĐÓNG cửa sổ Ubuntu và mở lại (để nhóm docker có hiệu lực), rồi kiểm tra:
  docker run --rm hello-world
EOF
