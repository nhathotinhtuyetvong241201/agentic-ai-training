#!/usr/bin/env bash
# Serve model bằng vLLM. Mặc định tinh chỉnh cho 1x RTX 5060 Ti 16GB.
# Override bằng biến môi trường, vd: MODEL=Qwen/Qwen3-14B-AWQ MAX_LEN=24576 ./vllm_serve.sh
set -euo pipefail

MODEL="${MODEL:-Qwen/Qwen3-8B-AWQ}"
SERVED_NAME="${SERVED_NAME:-$MODEL}"
TP="${TP:-1}"
# Tool-call parser phải khớp với model:
#   Qwen2.5 / Qwen3 -> hermes | Qwen3-Coder -> qwen3_coder | Llama3.x -> llama3_json
PARSER="${PARSER:-hermes}"
MAX_LEN="${MAX_LEN:-32768}"
# Windows vẫn giữ một ít VRAM cho desktop/RDP, nên không để 0.95.
GPU_UTIL="${GPU_UTIL:-0.88}"
MAX_SEQS="${MAX_SEQS:-8}"
# Đặt REASONING_PARSER=qwen3 nếu bật thinking của Qwen3.
REASONING_PARSER="${REASONING_PARSER:-}"

args=(--served-model-name "$SERVED_NAME"
      --host 0.0.0.0 --port 8000
      --tensor-parallel-size "$TP"
      --max-model-len "$MAX_LEN"
      --gpu-memory-utilization "$GPU_UTIL"
      --max-num-seqs "$MAX_SEQS"
      --enable-auto-tool-choice
      --tool-call-parser "$PARSER"
      --enable-prefix-caching)
[[ -n "$REASONING_PARSER" ]] && args+=(--reasoning-parser "$REASONING_PARSER")

exec vllm serve "$MODEL" "${args[@]}"
