# Chạy mini-swe-agent + vLLM trên nhiều task và thu trajectory

> Đang dùng máy thuê RTX 5060 Ti / Windows 10? Làm theo [SETUP_MAY_THUE.md](SETUP_MAY_THUE.md) trước (cài WSL2, Docker, vLLM),
> rồi quay lại đây cho phần chấm điểm và Cách B.
>
> Đang dùng NVIDIA Run:ai (không cài được Docker)? Xem [SETUP_RUNAI.md](SETUP_RUNAI.md).

Có 2 cách. **Nên bắt đầu với Cách A** (đơn giản, chỉ cần mini-swe-agent). Chuyển sang **Cách B** (NeMo Gym) khi bạn cần
reward (chạy test SWE-bench để chấm resolved/không) hoặc muốn tích hợp vào pipeline RL của NeMo.

## Yêu cầu phần cứng

| Thành phần | Chạy ở đâu |
|---|---|
| vLLM server | Máy Linux có GPU NVIDIA |
| mini-swe-agent + Docker | Máy **Linux x86_64** có Docker (có thể là chính máy GPU) |

> Image SWE-bench (`docker.io/swebench/sweb.eval.x86_64.*`) chỉ có bản x86_64. Trên Mac Apple Silicon sẽ phải chạy giả lập,
> rất chậm và dễ lỗi, nên hãy chạy agent trên máy Linux.

---

## Cách A — mini-swe-agent thuần + vLLM

### Bước 1. Serve model bằng vLLM (máy GPU)

```bash
pip install vllm
```

```bash
MODEL=Qwen/Qwen3-Coder-30B-A3B-Instruct PARSER=qwen3_coder TP=2 ./vllm_serve.sh
```

Điểm quan trọng: config SWE-bench mặc định của mini-swe-agent dùng **tool calling** (tool `bash`), nên vLLM **bắt buộc** phải có
`--enable-auto-tool-choice --tool-call-parser <parser>`. Chọn parser theo model:

| Model | `--tool-call-parser` |
|---|---|
| Qwen3-Coder | `qwen3_coder` |
| Qwen2.5 / Qwen3 (instruct) | `hermes` |
| Llama 3.x | `llama3_json` |

Kiểm tra server đã lên:

```bash
curl http://localhost:8000/v1/models
```

### Bước 2. Cài mini-swe-agent (máy chạy agent, Python ≥ 3.10)

```bash
git clone https://github.com/SWE-agent/mini-swe-agent.git
```

```bash
uv venv -p 3.11 .venv && source .venv/bin/activate && uv pip install -e ./mini-swe-agent
```

Kiểm tra Docker chạy được:

```bash
docker run --rm hello-world
```

### Bước 3. Trỏ mini-swe-agent tới vLLM

Sửa [vllm_model.yaml](vllm_model.yaml):

- `model.model_name`: `hosted_vllm/<tên model>` — phần sau `hosted_vllm/` phải **trùng** `--served-model-name` của vLLM.
- `model.model_kwargs.api_base`: `http://<ip-máy-gpu>:8000/v1`.
- `agent.step_limit`: số bước tối đa mỗi task (mặc định gốc là 250, ở đây đặt 100 cho nhanh).
- `cost_tracking: ignore_errors` + `cost_limit: 0`: tắt tính tiền vì model local không có bảng giá trong litellm.

File này là *overlay*: nó được merge lên trên `swebench.yaml` gốc (giữ nguyên prompt, environment docker, v.v.).

### Bước 4. Chạy thử 1 task

```bash
FILTER='^(django__django-11099)$' WORKERS=1 OUT=runs/smoke ./run_batch.sh
```

Lần đầu sẽ lâu vì phải `docker pull` image của task (vài GB). Nếu bị timeout lúc pull, thêm
`EXTRA_CONFIG="-c environment.pull_timeout=1200"`.

### Bước 5. Chạy nhiều task song song

```bash
SUBSET=verified SPLIT=test SLICE=0:50 WORKERS=8 OUT=runs/verified_0_50 ./run_batch.sh
```

Các biến của [run_batch.sh](run_batch.sh):

| Biến | Ý nghĩa | Mặc định |
|---|---|---|
| `SUBSET` | `lite`, `verified`, `full`, `smith`, `rebench`, hoặc đường dẫn dataset riêng (định dạng SWE-bench) | `verified` |
| `SPLIT` | split của dataset | `test` |
| `SLICE` | lấy một đoạn task, vd `0:50` | `0:5` |
| `FILTER` | regex lọc `instance_id` (khi đặt thì bỏ qua `SLICE`) | rỗng |
| `WORKERS` | số task chạy song song | `4` |
| `OUT` | thư mục output | `runs/<timestamp>` |
| `EXTRA_CONFIG` | override thêm, vd `-c agent.step_limit=50 -c model.model_kwargs.temperature=1.0` | rỗng |

Gợi ý `WORKERS`: mỗi worker = 1 container Docker + 1 request song song tới vLLM. Bắt đầu 4–8, tăng dần theo CPU/RAM máy chạy agent
và throughput của vLLM.

Chạy lại cùng `OUT` sẽ **bỏ qua task đã xong** (dựa trên `preds.json`) — tiện khi bị ngắt giữa chừng. Muốn chạy lại hết thì thêm
`--redo-existing` vào lệnh `mini-extra swebench` trong script.

Muốn thu nhiều trajectory cho cùng một task (vd để rejection sampling): chạy nhiều lần với `OUT` khác nhau và temperature > 0.

### Bước 6. Lấy trajectory

Sau khi chạy, cấu trúc output:

```
runs/verified_0_50/
├── preds.json                       # patch cuối cùng của mỗi task (định dạng SWE-bench)
├── trajectories.jsonl               # do collect_trajs.py gom lại (1 dòng / task)
├── minisweagent.log
├── exit_statuses_*.yaml             # thống kê Submitted / LimitsExceeded / lỗi ...
└── <instance_id>/<instance_id>.traj.json   # trajectory đầy đủ (kể cả raw response)
```

Mỗi dòng của `trajectories.jsonl`:

```json
{"instance_id": "...", "exit_status": "Submitted", "submission": "diff --git ...", "n_steps": 23,
 "api_calls": 23, "model": "hosted_vllm/...",
 "messages": [{"role": "system", ...}, {"role": "user", ...},
              {"role": "assistant", "content": "...", "tool_calls": [...]},
              {"role": "tool", "tool_call_id": "...", "content": "<returncode>0</returncode>..."}, ...]}
```

`messages` theo đúng định dạng OpenAI chat + tool calls, dùng được ngay cho SFT. Các tuỳ chọn của
[collect_trajs.py](collect_trajs.py):

```bash
python collect_trajs.py runs/verified_0_50 --only-submitted -o sft.jsonl
```

- `--only-submitted`: chỉ giữ task agent đã nộp patch.
- `--keep-raw`: giữ nguyên trường `extra` (raw response vLLM, timestamp, returncode...).

Xem trajectory bằng giao diện:

```bash
mini-extra inspector runs/verified_0_50
```

### Bước 7 (tuỳ chọn). Chấm điểm — task nào resolved?

`Submitted` chỉ có nghĩa là agent đã nộp patch, chưa chắc đúng. Để biết resolved, chạy harness SWE-bench trên `preds.json`:

```bash
pip install swebench
```

```bash
python -m swebench.harness.run_evaluation --dataset_name princeton-nlp/SWE-bench_Verified --predictions_path runs/verified_0_50/preds.json --max_workers 8 --run_id verified_0_50
```

Rồi join kết quả (`resolved_ids` trong file report) với `trajectories.jsonl` theo `instance_id` để lọc trajectory thành công.

---

## Cách B — qua NeMo Gym (`mini_swe_agent_2`)

NeMo Gym bọc mini-swe-agent thành một agent server: mỗi task chạy agent **và** tự chạy test SWE-bench, trả về rollout có `reward`
(1.0 nếu resolved). Phù hợp khi bạn cần dữ liệu có nhãn đúng/sai hoặc sẽ train RL bằng NeMo RL.

### B1. Cài NeMo Gym

```bash
git clone https://github.com/NVIDIA-NeMo/Gym.git nemo-gym && cd nemo-gym
```

```bash
uv sync --locked --extra dev --extra sandbox
```

Không cần tự cài mini-swe-agent: `gym env start` tự tạo venv riêng cho agent (pin `mini-swe-agent==2.1.0`, `swebench==4.1.0`).

### B2. Khai báo endpoint vLLM

Tạo `env.yaml` ở thư mục gốc `nemo-gym/`:

```yaml
policy_base_url: http://<ip-máy-gpu>:8000/v1
policy_api_key: dummy
policy_model_name: Qwen/Qwen3-Coder-30B-A3B-Instruct
```

vLLM vẫn serve như Bước 1 của Cách A. Nếu model không có reasoning parser, thêm override
`+policy_model.responses_api_models.vllm_model.uses_reasoning_parser=false`.

### B3. Khởi động server (terminal 1) — dùng sandbox Docker local

```bash
gym env start --config responses_api_agents/mini_swe_agent_2/configs/mini_swe_agent_2.yaml --config nemo_gym/sandbox/providers/docker/configs/docker.yaml --model-type vllm_model
```

(README của agent dùng OpenSandbox; ở đây thay bằng provider `docker` chỉ bằng cách đổi config path thứ hai.)

### B4. Thu rollout (terminal 2)

Chạy thử 1 task trong 5 task mẫu:

```bash
gym eval run --no-serve --agent mini_swe_agent_2 --input responses_api_agents/mini_swe_agent_2/data/example.jsonl --output results/smoke.jsonl --limit 1 --num-repeats 1 --concurrency 1 --temperature 0.6 --top-p 0.95 --max-output-tokens 16384
```

Nhiều task, nhiều lần lặp (pass@k):

```bash
gym eval run --no-serve --agent mini_swe_agent_2 --input responses_api_agents/mini_swe_agent_2/data/example.jsonl --output results/pass4.jsonl --num-repeats 4 --concurrency 8 --temperature 0.6 --top-p 0.95 --max-output-tokens 16384
```

Muốn chạy dataset của bạn: tạo JSONL, mỗi dòng là một instance SWE-bench đầy đủ trường (`instance_id`, `repo`, `base_commit`,
`problem_statement`, `patch`, `test_patch`, `FAIL_TO_PASS`, `PASS_TO_PASS`, `version`...) **cộng thêm**
`"responses_create_params": {"input": []}` — xem mẫu ở `responses_api_agents/mini_swe_agent_2/data/example.jsonl`.

### B5. Output

- `results/pass4.jsonl`: mỗi dòng một rollout với `reward`, `response` (toàn bộ trajectory theo Responses API),
  `metadata.model_patch`, `metadata.eval_report`.
- `results/pass4_aggregate_metrics.json`: pass@k, số task resolved, tỉ lệ lỗi.
- `results/<subset>/<policy_model_name>/`: trajectory + config gốc của mini-swe-agent cho từng instance
  (định dạng `.traj.json` giống Cách A, nên `collect_trajs.py` cũng đọc được nếu bạn trỏ vào đúng thư mục).

---

## Lỗi hay gặp

| Triệu chứng | Nguyên nhân / cách sửa |
|---|---|
| `"auto" tool choice requires --enable-auto-tool-choice` | vLLM thiếu cờ tool calling — xem Bước 1 |
| Agent liên tục báo `Tool call error` / `FormatError` | Sai `--tool-call-parser` cho model, hoặc model quá yếu với tool calling. Thử parser khác, hoặc dùng config dạng text: thay `-c swebench.yaml` bằng `-c swebench_backticks.yaml` và thêm `-c model.model_class=litellm_textbased` (khi đó không cần tool parser) |
| Lỗi cost / `model not mapped` | Thiếu `cost_tracking: ignore_errors` (đã có trong `vllm_model.yaml`) |
| `finish_reason=length` liên tục | Tăng `max_tokens` trong `vllm_model.yaml` hoặc `--max-model-len` của vLLM; context trajectory dài nên cần ≥ 32k |
| Task kẹt ở "initializing" | Đang `docker pull` image; tăng `environment.pull_timeout` hoặc pull trước |
| Muốn chạy lại task đã xong | Xoá entry tương ứng trong `preds.json` hoặc dùng `--redo-existing` |
