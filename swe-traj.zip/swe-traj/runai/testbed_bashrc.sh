# BASH_ENV cho mọi lệnh của agent: kích hoạt conda env `testbed` (nơi repo của task được cài).
# Cần vì image SWE-rebench chỉ `conda activate base` trong /root/.bashrc; image SWE-bench gốc thì activate testbed sẵn.
[ -f /root/.bashrc ] && . /root/.bashrc
for c in /opt/miniconda3 /opt/conda; do
  [ -f "$c/etc/profile.d/conda.sh" ] && . "$c/etc/profile.d/conda.sh" && break
done
conda activate testbed 2>/dev/null || true
