#!/usr/bin/env bash
# Lệnh (command) của workload Run:ai: chạy agent cho 1 task NGAY TRONG container image của task đó (không cần Docker).
#   bash <ROOT>/swe-traj/runai/run_task.sh [instance_id]
# Mặc định: task 0b01001001__spectree-64 của SWE-rebench (split filtered).
set -euo pipefail
IID="${1:-0b01001001__spectree-64}"
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SUBSET="${SUBSET:-rebench}"
SPLIT="${SPLIT:-filtered}"
OUT="$ROOT/runs/${RUN_NAME:-runai}/$IID"   # mỗi task 1 thư mục riêng

echo "user=$(id -un) uid=$(id -u)  ROOT=$ROOT  OUT=$OUT"
touch /testbed/.mswea_write_test && rm /testbed/.mswea_write_test \
  || { echo "Không ghi được /testbed: workload phải chạy bằng root (user mặc định của image)." >&2; exit 1; }

export HF_HOME="$ROOT/hf" HF_DATASETS_OFFLINE=1 HF_HUB_OFFLINE=1
export MSWEA_COST_TRACKING=ignore_errors PYTHONPATH="$ROOT/swe-traj/runai"
cd "$ROOT/swe-traj"
filter="^$(printf '%s' "$IID" | sed 's/[][\.*^$()+?{}|]/\\&/g')\$"
# shellcheck disable=SC2086
"$ROOT/mswea-venv/bin/mini-extra" swebench --subset "$SUBSET" --split "$SPLIT" --filter "$filter" -w 1 -o "$OUT" \
  --redo-existing -c swebench.yaml -c vllm_model.yaml -c runai/local_env.yaml \
  -c "environment.env.BASH_ENV=$ROOT/swe-traj/runai/testbed_bashrc.sh" ${EXTRA_CONFIG:-}

"$ROOT/mswea-venv/bin/python" collect_trajs.py "$OUT"
