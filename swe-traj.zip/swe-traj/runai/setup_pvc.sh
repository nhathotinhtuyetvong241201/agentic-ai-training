#!/usr/bin/env bash
# Chạy 1 lần trong terminal của Jupyter workload (Run:ai) để chuẩn bị PVC dùng chung:
#   <ROOT>/swe-traj      script + config (thư mục này)
#   <ROOT>/mswea-venv    Python 3.12 + mini-swe-agent (python do uv tải về cũng nằm trên PVC)
#   <ROOT>/hf            cache dataset Hugging Face (workload task chạy offline)
# ROOT = thư mục cha của swe-traj, tức mount path của PVC. Workload task phải mount PVC ở ĐÚNG đường dẫn này.
#   bash swe-traj/runai/setup_pvc.sh            (mặc định SUBSET=rebench SPLIT=filtered)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SUBSET="${SUBSET:-rebench}"
SPLIT="${SPLIT:-filtered}"
echo "ROOT=$ROOT"

export PATH="$HOME/.local/bin:$PATH"
command -v uv >/dev/null || pip install --user -q uv
export UV_PYTHON_INSTALL_DIR="$ROOT/uv-python"
[[ -d "$ROOT/mswea-venv" ]] || uv venv -p 3.12 --python-preference only-managed "$ROOT/mswea-venv"
uv pip install -p "$ROOT/mswea-venv/bin/python" -q mini-swe-agent

echo "Tải dataset $SUBSET/$SPLIT vào $ROOT/hf ..."
HF_HOME="$ROOT/hf" MSWEA_SILENT_STARTUP=1 "$ROOT/mswea-venv/bin/python" -c "
from datasets import load_dataset
from minisweagent.run.benchmarks.swebench import DATASET_MAPPING
print(load_dataset(DATASET_MAPPING.get('$SUBSET', '$SUBSET'), split='$SPLIT'))"

cat <<MSG

Xong. Kiểm tra model_kwargs.api_base trong $ROOT/swe-traj/vllm_model.yaml là địa chỉ vLLM mà POD KHÁC truy cập được
(không phải localhost). Rồi tạo workload Run:ai theo SETUP_RUNAI.md, command:
  bash $ROOT/swe-traj/runai/run_task.sh 0b01001001__spectree-64
MSG
