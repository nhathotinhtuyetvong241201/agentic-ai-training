"""LocalEnvironment chạy lệnh bằng `bash -c` thay vì /bin/sh.

Dùng khi agent chạy NGAY TRONG container image SWE-bench (vd Run:ai workload, không có Docker):
swebench.yaml đặt BASH_ENV=/root/.bashrc, file này `conda activate testbed`, nhưng chỉ bash mới đọc BASH_ENV.
"""

import shlex

from minisweagent.environments.local import LocalEnvironment


class BashLocalEnvironment(LocalEnvironment):
    def execute(self, action: dict, cwd: str = "", *, timeout: int | None = None) -> dict:
        command = "bash -c " + shlex.quote(action.get("command", ""))
        return super().execute({**action, "command": command}, cwd, timeout=timeout)
